# 6-seed active-vs-raster belief-covariance comparison

This is the actual code, raw output, and figure from the comparison run earlier in this
conversation. Packaged as-is so it can be independently checked, rather than trusted from a
chat transcript — per this project's own stated policy (Primer Section 13).

## What this is

- `covariance_comparison.py` — the script that produced the result. Compares, over 6 seeds,
  how fast within-particle covariance (normalized logdet) drops for an active (BALD+FIM)
  policy vs. a fixed raster-scan policy, given the same ground truth, prior, particle count,
  and noise model.
- `covariance_comparison.json` — raw per-seed, per-step covariance traces (the actual numbers
  the plot was built from).
- `active_vs_raster_covariance.png` — the resulting figure.
- `snapshot_code_used/` — an exact copy of every module this script actually imported and ran
  against at the time (`qarray_env.py`, `particle_filter.py`, `candidate_search.py`, etc.).

## What this is NOT

- **Not run against the current, fixed codebase.** `snapshot_code_used/` predates:
  - Section 4d's discrete-state-collapse fix (mixture likelihood + adaptive tempering).
  - Section 4c's analytic JAX Jacobian (this snapshot used the older adaptive-FD Jacobian).
  - Section 4e's temperature-convention fix (`T≈100`; this snapshot likely used a much
    colder, unphysical `T`).
  - Section 5's Phase-0 candidate-proposal gap being closed as a first-class, tested module
    (this run does include a coarse-sweep call, but against the pre-4d/4c/4e state).
- **Not independently reproduced.** This is one session's run, not checked against a second
  run or a second reviewer.
- **Not confirmed uncorrupted by the 4d collapse bug.** If the discrete-state collapse
  described in Primer Section 4d was present and active during this run (plausible, since the
  fix postdates it), the "active beats raster" result may reflect two policies acting on an
  already-degenerate ensemble rather than a clean measurement of information-theoretic
  benefit. This cannot currently be ruled in or out from the artifacts here alone.

## Recommended next step

Re-run this same comparison against the current `snapshot_code_used`-equivalent modules in the
real repo (post-4d/4c/4e), and diff the results against this package. Until that's done, cite
this only as "a preliminary run under a since-superseded code state," not as validated evidence
for Claim 1.
